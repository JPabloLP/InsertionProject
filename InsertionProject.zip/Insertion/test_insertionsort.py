import insertionsort
def test_insertion_sort():
    assert insertionsort.insertion_sort([2,9,7,6,8]) == [2,6,7,8,9]